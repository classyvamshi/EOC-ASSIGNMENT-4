function M_U_X=MUX2(S0,D1,D0)
 
         x=N_O_T1(S0);
         y=A_N_D1(x,D1);
         z=A_N_D1(S0,D1);
         F=O_R1(y,z)
   end