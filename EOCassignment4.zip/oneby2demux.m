function DEMUX2=oneby2demux(in,sel)
  
a1=N_O_T1(sel);
A=A_N_D1(in,a1)
B=A_N_D1(sel,in)
end
